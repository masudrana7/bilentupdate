(function ($) {
    "use strict";

})(jQuery);